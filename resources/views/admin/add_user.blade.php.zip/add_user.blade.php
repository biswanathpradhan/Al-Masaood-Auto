<?php 
$language_id = Session::get('language_id');
$manage_users_translations = getbackendTranslations('manage_users',null,$language_id);
$breadcrumb_translations = getbackendTranslations('breadcrumb ',null,$language_id);
// breadcrumb_admin_manage
 ?> 
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <!-- <h1 class="m-0 text-dark">Add Model</h1> -->
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><i class="nav-icon fa fa-tachometer-alt"></i> @if ($breadcrumb_translations['breadcrumb_home']) {{$breadcrumb_translations['breadcrumb_home']}} @else Home @endif</a></li>
              <li class="breadcrumb-item"><a href="#">@if ($breadcrumb_translations['breadcrumb_admin_manage']) {{$breadcrumb_translations['breadcrumb_admin_manage']}} @else Admin Manage @endif</a></li>
              <li class="breadcrumb-item active">@if ($manage_users_translations['add_user']) {{$manage_users_translations['add_user']}} @else Add User @endif </li>
            </ol>
          </div>
        </div>

      </div>
    </div>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6">
            <div class="card card-secondary">
              <div class="card-header">
                <h3 class="card-title">@if ($manage_users_translations['add_user']) {{$manage_users_translations['add_user']}} @else Add User @endif </h3>
              </div>
              <form role="form" method="post" action="{{route('saveuser')}}" enctype="multipart/form-data">
                @csrf
                <div class="card-body">
              
                      
                  <!-- <div class="form-group"> -->
         
            <div class="form-row">
            <div class="col">
                  
  
        <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-cog"></span> @if ($manage_users_translations['roles']) {{$manage_users_translations['roles']}} @else Roles @endif  <span class="caret"></span></button>
  <ul class="dropdown-menu checkbox-menu" style="top: auto;">

<?php $i=0; while ( count($roles) > $i) {

 ?>
  <li> <label><a href="#" class="small" data-value="<?php  echo  $roles[$i]['role_id']; ?>" tabIndex="-1"><input  class="form-check-label" name="role_id[]" value="<?php  echo  $roles[$i]['role_id']; ?>" type="checkbox"/>&nbsp;<?php  echo  $roles[$i]['menu_name']; ?></a> </label></li>

<?php  $i++; } ?>
 
</ul>
  

                </div>
                </div>
                  
         
       
         
         <div class="form-row">
           
            <div class="col">
              <label for="exampleInputEmail1"> @if ($manage_users_translations['email']) {{$manage_users_translations['email']}} @else Email @endif</label>
              <input type="text" class="form-control" id="email" name="email" placeholder="@if ($manage_users_translations['email']) {{$manage_users_translations['email']}} @else Email @endif" required="required">
            </div>
          </div>
          <div class="form-row">
           
            <div class="col">
              <label for="exampleInputEmail1">@if ($manage_users_translations['password']) {{$manage_users_translations['password']}} @else Password @endif</label>
              <input type="text" class="form-control" id="password" name="password" placeholder="@if ($manage_users_translations['password']) {{$manage_users_translations['password']}} @else Password @endif" required="required">
            </div>
          </div>
          <div style="padding-top: 15px;"></div>
                
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">@if ($manage_users_translations['btn_submit']) {{$manage_users_translations['btn_submit']}} @else Submit @endif </button>
                  <button  type="button" onclick="window.history.back()" class="btn btn-primary">@if ($manage_users_translations['btn_cancel']) {{$manage_users_translations['btn_cancel']}} @else Cancel @endif</button>
                </div>
              </form>
            </div>
          
           
          </div>
         
        </div>
      </div>
    </section>
 <style type="text/css">
   .checkbox-menu li label {
    display: block;
    padding: 3px 10px;
    clear: both;
    font-weight: normal;
    line-height: 1.42857143;
    color: #333;
    white-space: nowrap;
    margin:0;
    transition: background-color .4s ease;
}
.checkbox-menu li input {
    margin: 0px 5px;
    top: 2px;
    position: relative;
}

.checkbox-menu li.active label {
    background-color: #cbcbff;
    font-weight:bold;
}

.checkbox-menu li label:hover,
.checkbox-menu li label:focus {
    background-color: #f5f5f5;
}

.checkbox-menu li.active label:hover,
.checkbox-menu li.active label:focus {
    background-color: #b8b8ff;
}
   
 </style>